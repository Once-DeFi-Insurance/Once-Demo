export { default } from "./InchDex";
