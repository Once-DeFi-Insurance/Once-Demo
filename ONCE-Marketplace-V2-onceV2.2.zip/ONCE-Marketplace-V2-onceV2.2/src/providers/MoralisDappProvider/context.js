import React from "react";

const MoralisDappContext = React.createContext();

export default MoralisDappContext;
