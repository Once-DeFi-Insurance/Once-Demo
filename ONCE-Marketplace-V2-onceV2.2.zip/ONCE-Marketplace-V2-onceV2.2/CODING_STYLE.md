# Coding Style

- Most importantly, match the existing code style as much as possible.
- Follow the ESlint rules for code-styling and Prettier rules for formatting
